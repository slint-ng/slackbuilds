
#include "widgets/toolbar/toolbar.h"

Toolbar::Toolbar(Widget* parent) : Widget(parent)
{
}

Toolbar::~Toolbar()
{
}
