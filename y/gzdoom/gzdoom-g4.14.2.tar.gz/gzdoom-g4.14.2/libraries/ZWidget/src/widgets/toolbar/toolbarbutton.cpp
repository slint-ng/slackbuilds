
#include "widgets/toolbar/toolbarbutton.h"

ToolbarButton::ToolbarButton(Widget* parent) : Widget(parent)
{
}

ToolbarButton::~ToolbarButton()
{
}

void ToolbarButton::OnPaint(Canvas* canvas)
{
}
