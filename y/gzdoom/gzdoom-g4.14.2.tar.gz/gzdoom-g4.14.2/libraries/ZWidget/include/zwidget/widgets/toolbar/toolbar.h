
#pragma once

#include "../../core/widget.h"

class Toolbar : public Widget
{
public:
	Toolbar(Widget* parent);
	~Toolbar();
};
