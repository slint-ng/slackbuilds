This bank (gm.wopn and xg.wopn) is made by me. I have imported some instruments from various
VGM files, ported from OPL3 banks, or remixed them.

This bank can be freely used, modified, shared with any purposes.

License for this bank - MIT

To edit this bank and other banks in WOPN format, you can use this editor
which I created for that: https://github.com/Wohlstand/OPN2BankEditor

==============================================================================

Vitaliy Novichkov "Wohlstand", 2017-2018

